#include "vector2d.h"
#include <cmath>

v2d::v2d(double a, double b) : x(a), y(b) {
    
}

v2d::v2d(const v2d & v) : x(v.x), y(v.y) {
    
}

v2d::~v2d() {

// there shall be no code here.
    // If anybody is reading this, this was made on the 22 oktober, i didn't see that exercise 6 was not this sighhhhhh.......
}

v2d & v2d::operator=(const v2d &v) {
    
    // this should just copy from one vector to the other
        this->x = v.x;
        this->y = v.y;

        return *this; //returning duh!
    
}
v2d & v2d::operator+(const v2d &v) {
    //returns the addition of the two vectors, somehow it must return a pointer to the very vector for the code to work ¯\_(ツ)_/¯
    this->x += v.x;
    this->y += v.y;
    return *this;
}



double v2d::operator*(const v2d &v) {
    //Finds the produkt of two vectors
    return (this->x * v.x) + (this->y * v.y);
}

v2d v2d::operator*(double k) {
    // returns a new vector object scaled by K.
    return v2d(this->x * k, this->y * k);
}


double v2d::length() {
    return sqrt(x*x +y*y);
}

