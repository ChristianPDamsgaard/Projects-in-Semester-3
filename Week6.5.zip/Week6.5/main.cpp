#include <iostream>
class frac {

    private: 
    int x; 
    int y;

public:

frac(int a, int b) : x(a), y(b){

} 
frac() : x(0), y(1) { }
//frac::frac(const frac & f): x(f.x), y(f.y){


//}


~frac(){


}

frac &add(const frac &f) {
    this->x = this->x * f.y + this->y * f.x; // New top part of fraction
    this->y = this->y * f.y; // New bottom part
    roundDown(this->x, this->y); //remember to roundown constantly, makes things Easier!
    return *this; 
}

frac &mult(const frac &f) {
    this->x = this->x * f.x; 
    this->y = this->y * f.y;
    roundDown(this->x, this->y);
    return *this; 
}

frac &div(const frac &f) { // made the division more proper, by instead of brute forcing by simply using division symbols, we use the proper method of finding the produkt by the inverse of the fraktion.
    this->x = this->x * f.y; 
    this->y = this->y * f.x;
    roundDown(this->x, this->y);
    return *this; 
}


void roundDown(int &a, int &b){
for(int i = 2; i <= 20; i++){
   if(a % i == 0 && b % i == 0){
    a = a /i; 
    b = b /i;
   }
}

}
void print() const { // Fixed bug here, fractions should come out as whole numbers when say 1/1, but they should simply remain a fraction. 
        std::cout << x << " / " << y << std::endl;  // Print as x / y
}


};
//// NOW EVERYTHING SHOULD BE TOGETHER IN ONE FILE WITH NO ISSUES, IT SEEMS TO WORK ONWARDS!

// Function to read fraction from user input
void readFraction(int &num, int &den) {
    std::cin >> num;
    std::cin.ignore(256, '/'); // Ignore the '/' character, mmhm handy yes
    std::cin >> den;
}

int main() {

    while(true){
    int a, b, c, d;
    std::string operation;

    // Read fractions a/b and c/d from input
   // std::cout << "Enter first fraction (a / b): ";
    readFraction(a, b); // Read a / b

    //std::cout << "Enter operation (+, *, div): ";
    std::cin >> operation; // Read the operation
    if(std::cin.fail()){
        return 0;
    }
    //std::cout << "Enter second fraction (c / d): ";
    readFraction(c, d); // Read c / d

    
    frac f1(a, b);
    frac f2(c, d);
    frac result;

    
    if (operation == "+") {
        result = f1.add(f2);
    } else if (operation == "*") {
        result = f1.mult(f2);
    } else if (operation == "div") {
        result = f1.div(f2);
    } else {
        std::cerr << "Invalid operation!" << std::endl;
        return 1;
    }
 
    
   // std::cout << "Result: ";
    result.print();
    }
    return 0;
    
}
