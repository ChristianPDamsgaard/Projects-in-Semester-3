#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

int findTrueSize(char a1, std::vector<int> v);

void formVektor(char a, std::vector<int>& v1, std::vector<int>& v2, std::string s) {
    for (int i = 0; i < s.size(); i++) {
        if (i + 1 >= s.size()) {
            // Skip the last character if it's not followed by a number, OTHERWISE WE WILL GET -48 FOR SOME REASON, I THINK IT IS ALLOCATING RANDOM MEMORY
            break;
        }

        if (s[i] == a) {
            char num = s[i + 1];
            if (isdigit(num)) {
                int n = num - '0';  
                v1.push_back(n);
             //   std::cout << n << " ";  // OBS REMOVE LATER
            }
        } else {
            char num = s[i + 1];
            if (isdigit(num)) {
                int n = num - '0'; 
                v2.push_back(n);
              //  std::cout << n << " ";  // print for testing right now, OBS remove later
            }
        }
    }
}

std::vector<int> mergeVectors(std::vector<int>& v1, std::vector<int>& v2){
    std::vector<int> merged;
        for(int i = 0; i <= ((v1.size()+v2.size())/2); i++){
            if(i < v1.size()){
                merged.push_back(v1[i]);
            } 
            if(i < v2.size()){
                merged.push_back(v2[i]);
            }
        }


    return merged;
}


void sortVectors(std::vector<int> & v1, std::vector<int>& v2) {
    // Sort the vectors
    std::sort(v1.begin(), v1.end());
    std::sort(v2.begin(), v2.end());


}

void removeSpaces(const std::string& input, std::string& output) {
    for (char c : input) {
        if (c != ' ') {
            output += c;  // Append non-space character to output string
        }
    }
}

 void printVector(const std::vector<int>& vec, const std::string& vecName) { // just for soem testin'
   // std::cout << vecName << ": ";
    for (int elem : vec) {
        std::cout << elem << " ";  // Print each element
    }
   // std::cout << std::endl;
} 
int findTrueSize(char a1, std::vector<int> v){
    int count = 0;
    for(int i = 0; i < v.size(); i++){
        if(v[i] == a1){
            count++;
        }
    }
    return count;


}

int main() {
    std::vector<int> v1, v2, t1,t2;
    std::string s;  // Input string
    std::getline(std::cin, s);  // Read the entire line (including spaces)
    char a = 'a';  // Looking for 'a'
    char b = 'b';

    std::string result = "";  // Will store the string without spaces
    removeSpaces(s, result);  // Call function to remove spaces


   formVektor(a, v1, v2, result);  // Use the modified string
   //sortVectors(v1, v2);  // Sort the vectors
/*    printVector(v1, "v1");
   printVector(v2, "v2"); */
   printVector(mergeVectors(v1, v2), "merged");

    return 0;
}

